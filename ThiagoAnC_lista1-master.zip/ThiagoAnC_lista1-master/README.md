# C-S_python_zmq
 Client/Server application using ZMQ

This is intended to be able to solve the first list of exercises of distributed systems' class.
Just launch all the nodes and communicate!
